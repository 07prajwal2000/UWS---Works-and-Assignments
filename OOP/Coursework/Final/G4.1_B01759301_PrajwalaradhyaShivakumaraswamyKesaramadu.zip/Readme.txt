OOP Coursework

Students Contribution Percentage
1.	Prajwalaradhya Shivakumaraswamy Kesaramadu (B01759301) - 20%. Week 5 & Week 8
2.	Muhammed Ali Panthalingal (B01755979) - 20%. Week 4 &  Week 2
3.	Stephen Kwaku Pometsey (B01757368) - 20%. Week 4 & Week 6
4.	Aman Misra (B01746656) - 20%. Week 2 & Week 3.
5.	Sreeraj Karuvanthodi Ramachandran (B01764963) - 20%. Week 2 & Week 3.

For week 4 and 6 Python code is included and mixed with the portfolio files i.e. task.py, taskdao.py, tasklist.py, main.py and users.py.